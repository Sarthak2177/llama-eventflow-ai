"""Solace Event Portal Designer MCP Server."""
__version__ = "0.1.2"
